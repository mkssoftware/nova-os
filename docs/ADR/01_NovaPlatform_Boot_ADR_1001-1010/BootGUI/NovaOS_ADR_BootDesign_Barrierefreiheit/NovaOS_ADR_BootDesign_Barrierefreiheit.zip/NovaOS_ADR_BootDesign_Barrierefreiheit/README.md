# NovaOS BootDesign & Accessibility ADRs
